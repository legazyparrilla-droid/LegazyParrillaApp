# Legazy Parrilla App

Aplicación Android inicial de Legazy Parrilla.

## Incluye
- Inicio de Legazy Parrilla.
- Menú.
- Bandejas familiares y para compartir desde RD$1,500.
- Pedidos y cotizaciones por WhatsApp: 809-759-3293.
- Acceso a Instagram: @legazyparrilla1.
- Flujo automático de GitHub Actions para generar el APK Debug.

## Generar APK en GitHub
1. Sube todos estos archivos al repositorio `LegazyParrillaApp`.
2. Ve a **Actions**.
3. Ejecuta **Build Legazy Parrilla APK** con **Run workflow**.
4. Cuando termine, entra al resultado de la ejecución y descarga el artefacto **Legazy-Parrilla-APK**.

## Nota
El logo incluido es un icono provisional inspirado en el concepto del toro. Se puede sustituir por el logo oficial de Legazy Parrilla cuando esté disponible como archivo de imagen.
