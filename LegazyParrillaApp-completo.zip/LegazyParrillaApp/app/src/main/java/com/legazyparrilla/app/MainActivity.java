package com.legazyparrilla.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.*;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity {
    LegazyView view;
    @Override public void onCreate(Bundle b){ super.onCreate(b); view=new LegazyView(); setContentView(view); }

    void whatsapp(String text){
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/18097593293?text="+Uri.encode(text)))); }
        catch(Exception e){ Toast.makeText(this,"No se pudo abrir WhatsApp",Toast.LENGTH_SHORT).show(); }
    }
    void instagram(){ try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/legazyparrilla1"))); } catch(Exception e){} }

    class LegazyView extends View {
        Paint p=new Paint(3); int page=0; Bitmap logo;
        int orange=Color.rgb(255,138,0), cream=Color.rgb(255,244,223), bg=Color.rgb(11,11,13), card=Color.rgb(27,27,31), muted=Color.rgb(170,170,178);
        String[] names={"Costillas al barril","Chicharrón al barril","Bandeja Legazy Familiar","Bandeja para compartir","Plato del día","Postre Brassa","Jugos naturales"};
        String[] prices={"Especialidad Legazy","Especialidad Legazy","Desde RD$1,500","Desde RD$1,500","Pregunta por el plato de hoy","Postre exclusivo","Refrescantes y naturales"};
        LegazyView(){ super(MainActivity.this); setBackgroundColor(bg); logo=getBitmap(com.legazyparrilla.app.R.drawable.logo_bull); }
        Bitmap getBitmap(int id){ Drawable d=getResources().getDrawable(id); Bitmap b=Bitmap.createBitmap(120,120,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(b); d.setBounds(0,0,120,120); d.draw(c); return b; }
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){ p.setColor(color); p.setTextSize(size); p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); c.drawText(s,x,y,p); }
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,p);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); int w=getWidth(), h=getHeight();
            if(page==0) home(c,w,h); else if(page==1) menu(c,w,h); else if(page==2) bandejas(c,w,h); else contact(c,w,h); bottom(c,w,h);
        }
        void header(Canvas c,String title,int w){ text(c,"LEGAZY",24,48,24,orange,true); text(c,"PARRILLA",24,76,18,cream,true); text(c,title,24,124,30,cream,true); }
        void home(Canvas c,int w,int h){
            c.drawBitmap(logo,null,new Rect(w-142,18,w-22,138),p);
            text(c,"Sabor que se queda.",24,178,30,cream,true); text(c,"Parrilla • Barril • Compartir",24,207,17,muted,false);
            round(c,20,235,w-20,390,24,card); text(c,"🔥  ESPECIALIDADES",38,270,16,orange,true); text(c,"Costillas al barril",38,306,24,cream,true); text(c,"Chicharrón al barril",38,340,20,cream,true); text(c,"Cocción lenta • sabor intenso",38,372,15,muted,false);
            button(c,20,415,w-20,478,"PEDIR POR WHATSAPP",orange,Color.BLACK); button(c,20,492,w-20,555,"VER MENÚ COMPLETO",cream,Color.BLACK);
            round(c,20,580,w-20,690,24,card); text(c,"Bandejas para compartir",38,616,21,cream,true); text(c,"Familiares y eventos",38,646,16,muted,false); text(c,"Desde RD$1,500",38,676,18,orange,true);
        }
        void menu(Canvas c,int w,int h){ header(c,"MENÚ",w); float y=150; for(int i=0;i<names.length;i++){ round(c,20,y,w-20,y+82,18,card); text(c,names[i],38,y+34,19,cream,true); text(c,prices[i],38,y+61,14,i==2||i==3?orange:muted,false); y+=96; if(y>h-130) break; } }
        void bandejas(Canvas c,int w,int h){ header(c,"BANDEJAS",w); round(c,20,150,w-20,300,22,card); text(c,"LEGAZY FAMILIAR",38,188,21,cream,true); text(c,"Ideal para la familia",38,218,16,muted,false); text(c,"Desde RD$1,500",38,255,22,orange,true); button(c,38,270,w-38,295,"ORDENAR",cream,Color.BLACK);
            round(c,20,320,w-20,470,22,card); text(c,"PARA COMPARTIR",38,358,21,cream,true); text(c,"Excursiones • reuniones • eventos",38,388,15,muted,false); text(c,"Desde RD$1,500",38,425,22,orange,true); button(c,38,440,w-38,465,"ORDENAR",cream,Color.BLACK);
            round(c,20,500,w-20,620,22,card); text(c,"EVENTOS PRIVADOS",38,538,21,cream,true); text(c,"Cotiza tu bandeja a la medida",38,570,15,muted,false); button(c,38,580,w-38,612,"COTIZAR",orange,Color.BLACK);
        }
        void contact(Canvas c,int w,int h){ header(c,"CONTACTO",w); round(c,20,155,w-20,290,22,card); text(c,"📲 WhatsApp",38,195,20,cream,true); text(c,"809-759-3293",38,228,21,orange,true); text(c,"Pedidos y cotizaciones",38,257,15,muted,false); button(c,38,270,w-38,292,"ABRIR WHATSAPP",orange,Color.BLACK);
            round(c,20,315,w-20,440,22,card); text(c,"📸 Instagram",38,355,20,cream,true); text(c,"@legazyparrilla1",38,388,20,orange,true); text(c,"Síguenos para promociones",38,416,15,muted,false);
            round(c,20,465,w-20,610,22,card); text(c,"LEGAZY PARRILLA",38,505,23,cream,true); text(c,"Carne, fuego y sabor.",38,540,18,orange,true); text(c,"Tu próxima bandeja empieza aquí.",38,572,15,muted,false); button(c,38,585,w-38,615,"INSTAGRAM",cream,Color.BLACK);
        }
        void button(Canvas c,float l,float t,float r,float b,String s,int color,int tc){ round(c,l,t,r,b,18,color); p.setTextSize(15);p.setTypeface(Typeface.DEFAULT_BOLD);float tw=p.measureText(s);text(c,s,(l+r-tw)/2,t+(b-t)/2+6,15,tc,true); }
        void bottom(Canvas c,int w,int h){ int top=h-86; p.setColor(Color.rgb(20,20,23));c.drawRect(0,top,w,h,p); String[] a={"Inicio","Menú","Bandejas","Contacto"}; for(int i=0;i<4;i++){float x=w*(i+.5f)/4; if(page==i) round(c,x-42,top+10,x+42,top+50,20,Color.rgb(40,40,45)); text(c,new String[]{"⌂","☰","▣","☎"}[i],x-10,top+37,22,page==i?orange:muted,true); text(c,a[i],x-p.measureText(a[i])/2,top+70,12,page==i?cream:muted,false); } }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY();int h=getHeight(),w=getWidth();
            if(y>h-95){int i=(int)(x/(w/4));page=i;invalidate();return true;}
            if(page==0){ if(y>405&&y<485) whatsapp("Hola Legazy Parrilla, quiero hacer un pedido."); else if(y>485&&y<565){page=1;invalidate();} }
            else if(page==1){ if(y>140){whatsapp("Hola Legazy Parrilla, quiero información sobre el menú.");} }
            else if(page==2){ if((y>260&&y<315)||(y>430&&y<485)) whatsapp("Hola Legazy Parrilla, quiero ordenar una bandeja Legazy."); else if(y>565&&y<635) whatsapp("Hola Legazy Parrilla, quiero cotizar un evento privado."); }
            else { if(y>260&&y<310) whatsapp("Hola Legazy Parrilla, quiero hacer un pedido."); else if(y>560&&y<640) instagram(); }
            return true; }
    }
}
